import{dg as n}from"./index-D7MHVo65.js";function t(r){return r?.name??n}export{t as r};
