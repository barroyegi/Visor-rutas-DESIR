import{M as u}from"./index-D7MHVo65.js";function l(r,n){return r===null?n:new u({url:r.field("url")})}export{l};
