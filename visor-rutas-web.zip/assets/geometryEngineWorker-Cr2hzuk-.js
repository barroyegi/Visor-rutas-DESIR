import{O as e}from"./geometryEngineJSON-Bbz0nMA5.js";import"./index-D7MHVo65.js";function p(r){return(0,e[r.operation])(...r.parameters)}export{p as executeGEOperation};
