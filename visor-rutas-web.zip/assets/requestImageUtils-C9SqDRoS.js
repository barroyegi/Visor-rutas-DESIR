import{y as n}from"./index-D7MHVo65.js";async function r(a,t){const{data:e}=await n(a,{responseType:"image",...t});return e}export{r as t};
